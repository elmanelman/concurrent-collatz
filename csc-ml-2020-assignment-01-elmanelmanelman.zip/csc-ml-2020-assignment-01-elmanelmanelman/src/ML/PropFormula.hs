module ML.PropFormula where

import Data.List (nub)

type AtomicProp = String

data PropFormula = FFalse
                 | FTrue
                 | Atom AtomicProp
                 | Not PropFormula
                 | And PropFormula PropFormula
                 | Or PropFormula PropFormula
                 | Imp PropFormula PropFormula
                 | Iff PropFormula PropFormula

destAnd :: PropFormula -> (PropFormula, PropFormula)
destAnd (And a b) = (a, b)
destAnd _ = error "destAnd"

conjuncts :: PropFormula -> [PropFormula]
conjuncts (And p q) = conjuncts p ++ conjuncts q
conjuncts fm = [fm]

destOr :: PropFormula -> (PropFormula, PropFormula)
destOr (Or a b) = (a, b)
destOr _ = error "destAnd"

disjuncts :: PropFormula -> [PropFormula]
disjuncts (Or p q) = disjuncts p ++ disjuncts q
disjuncts fm = [fm]

destImp :: PropFormula -> (PropFormula, PropFormula)
destImp (Imp a b) = (a, b)
destImp _ = error "destImp"

antecedent :: PropFormula -> PropFormula
antecedent = fst . destImp

consequent :: PropFormula -> PropFormula
consequent = snd . destImp

destIff :: PropFormula -> (PropFormula, PropFormula)
destIff (Iff a b) = (a, b)
destIff _ = error "destIff"

onatoms :: (AtomicProp -> PropFormula) ->
           PropFormula -> PropFormula
onatoms f fm =
  case fm of
    Atom p -> f p
    Not p -> Not (onatoms f p)
    And p q -> And (onatoms f p) (onatoms f q)
    Or p q -> Or (onatoms f p) (onatoms f q)
    Imp p q -> Imp (onatoms f p) (onatoms f q)
    Iff p q -> Iff (onatoms f p) (onatoms f q)
    fm -> fm

overatoms :: (AtomicProp -> t -> t) ->
             PropFormula -> t -> t
overatoms f fm b =
  case fm of
    Atom p -> f p b
    Not p -> overatoms f p b
    And p q -> over2 p q
    Or p q -> over2 p q
    Imp p q -> over2 p q
    Iff p q -> over2 p q
    _ -> b
  where
    over2 p q = overatoms f p (overatoms f q b)

atomUnion :: Eq b => (AtomicProp -> [b]) -> PropFormula -> [b]
atomUnion f fm = nub (overatoms (\h t -> f h ++ t) fm [])
