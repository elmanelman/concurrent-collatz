module ML.Prop where

import ML.PropFormula

import Data.List (sort)

eval :: PropFormula -> (AtomicProp -> Bool) -> Bool
eval fm v = case fm of
  FFalse -> False
  FTrue -> True
  Atom p -> v p
  Not p -> not (eval p v)
  And p q -> eval p v && eval q v
  Or p q -> eval p v || eval q v
  Imp p q -> not (eval p v) || (eval q v)
  Iff p q -> eval p v == eval q v

atoms :: PropFormula -> [AtomicProp]
atoms = sort . atomUnion (\x -> [x])

onallvaluations :: Eq a => ((a -> Bool) -> b) -> (b -> b -> b)
                      -> (a -> Bool) -> [a] -> b
onallvaluations subfn comb v pvs =
  case pvs of
    [] -> subfn v
    p:ps -> let v' t q = if q == p then t else v q in
          comb (onallvaluations subfn comb (v' False) ps)
               (onallvaluations subfn comb (v' True) ps)

tautology :: PropFormula -> Bool
tautology fm = onallvaluations (eval fm) (&&) (const False) (atoms fm)

unsatisfiable :: PropFormula -> Bool
unsatisfiable = tautology . Not

satisfiable :: PropFormula -> Bool
satisfiable = not . unsatisfiable

(|=>) :: AtomicProp -> PropFormula -> (AtomicProp, PropFormula)
(|=>) = (,)

psubst :: [(AtomicProp, PropFormula)]
          -> PropFormula -> PropFormula
psubst sub = onatoms (\p -> applySub p (Atom p))
  where
    applySub p def =
      case lookup p sub of
        Just fm' -> fm'
        Nothing -> def

dual :: PropFormula -> PropFormula
dual fm =
  case fm of
    FTrue -> FFalse
    FFalse -> FTrue
    Atom p -> Atom p
    Not p -> Not (dual p)
    And p q -> Or (dual p) (dual q)
    Or p q -> And (dual p) (dual q)
    _ -> error "Formula involves connectives ==> and <=>"
