module ML.ArithExpr ( Expr(..), simplify ) where

data Expr = Var String
          | Const Integer
          | Add Expr Expr
          | Mul Expr Expr

simplify1 :: Expr -> Expr
simplify1 (Add (Const m) (Const n)) = Const (m + n)
simplify1 (Mul (Const m) (Const n)) = Const (m * n)
simplify1 (Add (Const 0) x) = x
simplify1 (Add x (Const 0)) = x
simplify1 (Mul (Const 0) _) = Const 0
simplify1 (Mul _ (Const 0)) = Const 0
simplify1 (Mul (Const 1) x) = x
simplify1 (Mul x (Const 1)) = x
simplify1 x = x

simplify :: Expr -> Expr
simplify (Add e1 e2) = simplify1 (Add (simplify e1) (simplify e2))
simplify (Mul e1 e2) = simplify1 (Mul (simplify e1) (simplify e2))
simplify e = e

