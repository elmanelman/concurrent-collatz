{-# LANGUAGE DeriveDataTypeable #-}
{-# LANGUAGE StandaloneDeriving #-}
{-# LANGUAGE FlexibleInstances #-}

module ML.Util.PropPPP where

import ML.PropFormula
import ML.Prop

import Data.Data (Data)
import qualified Language.Haskell.TH as TH
import qualified Language.Haskell.TH.Quote as Q
import qualified Language.Haskell.TH.Syntax as S
import Language.Haskell.TH.Quote (QuasiQuoter(..))

import qualified ML.Util.Lex as Lex
import Text.ParserCombinators.Parsec
import Text.ParserCombinators.Parsec.Expr

import ML.Util.Print (Print)
import Text.PrettyPrint.HughesPJ ((<+>))
import qualified ML.Util.Print as PP
import qualified Text.PrettyPrint.HughesPJ as PP
import TextShow

deriving instance Data PropFormula

formula :: Parser PropFormula
formula = buildExpressionParser formulaTable atomicFormula <?> "formula"

formulaTable :: OperatorTable Char () PropFormula
formulaTable = [ [ op "/\\" And AssocRight ]
               , [ op "\\/" Or  AssocRight ]
               , [ op "==>" Imp AssocRight ]
               , [ op "<=>" Iff AssocRight ]
               ]
  where op s f assoc = Infix (do { Lex.reservedOp s; return f }) assoc

atomicFormula :: Parser PropFormula
atomicFormula = pure FTrue <* Lex.reserved "true"
            <|> pure FFalse <* Lex.reserved "false"
            <|> (Lex.reserved "~" >> Not <$> atomicFormula)
            <|> Atom <$> Lex.identifier
            <|> (Lex.symbol "~" >> (Not . Atom) <$> Lex.identifier)
            <|> Lex.parens formula
            <?> "atomic formula"

pf :: QuasiQuoter
pf = QuasiQuoter
         (S.liftData . Lex.makeParser formula)
         undefined
         undefined
         undefined

instance Print PropFormula where
  pPrint = ppForm 0

deriving instance Show PropFormula

instance TextShow PropFormula where
  showb = fromString . PP.render . PP.pPrint

ppForm :: Int -> PropFormula -> PP.Doc
ppForm pr f = case f of
  FFalse -> PP.text "false"
  FTrue -> PP.text "true"
  Atom m -> PP.paren (pr > 12) $ PP.text m
  Not p -> paren (pr > 10) (ppPrefixFm 10) "~" p
  And p q -> paren (pr > 8) (ppInfixFm 8 "/\\") p q
  Or p q -> paren (pr > 6) (ppInfixFm 6 "\\/") p q
  Imp p q -> paren (pr > 4) (ppInfixFm 4 "==>") p q
  Iff p q -> paren (pr > 2) (ppInfixFm 2 "<=>") p q

ppPrefixFm :: Int -> String -> PropFormula -> PP.Doc
ppPrefixFm pr sym p = PP.text sym <> ppForm pr p

ppInfixFm :: Int -> String -> PropFormula -> PropFormula -> PP.Doc
ppInfixFm pr sym p q =
  let lev = if sym == "/\\" || sym == "\\/" then 0 else 2 in
  PP.hang (ppForm (pr+1) p <+> PP.text sym)
    lev (ppForm pr q)

paren :: Bool -> (a -> b -> PP.Doc) -> a -> b -> PP.Doc
paren p f x y =
  if p then PP.parens d else d
    where d = f x y


truthtable :: PropFormula -> IO ()
truthtable fm = putStrLn $ PP.render (truthtableDoc fm)
 where
  truthtableDoc fm' =
    let pvs = atoms fm'
        width = foldr (max . length . show) 5 pvs + 1
        fixw s = s ++ replicate (width - length s) ' '
        truthstring p = fixw (if p then "true" else "false")
        separator = replicate (width * length pvs + 9) '-'
        row v =
            let lis = map (truthstring . v) pvs
                ans = truthstring(eval fm' v) in
                [lis ++ [ans]]
        rows = onallvaluations row (++) (const False) pvs
        rowStr r = let (lis, ans) = splitAt (length r - 1) r in
                       (foldr (++) ("| " ++ head ans) lis)
    in PP.vcat [ PP.text (foldr (\s t -> fixw(show s) ++ t) "| formula" pvs)
               , PP.empty
               , PP.text separator
               , PP.empty
               , PP.vcat (map (PP.text . rowStr) rows)
               , PP.text separator
               ]
