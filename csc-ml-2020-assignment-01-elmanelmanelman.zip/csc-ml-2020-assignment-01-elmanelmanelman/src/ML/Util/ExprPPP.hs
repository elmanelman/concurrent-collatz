{-# LANGUAGE DeriveDataTypeable #-}
{-# LANGUAGE StandaloneDeriving #-}

module ML.Util.ExprPPP ( expr ) where

import ML.ArithExpr

import Data.Data (Data)
import qualified Language.Haskell.TH as TH
import qualified Language.Haskell.TH.Quote as Q
import qualified Language.Haskell.TH.Syntax as S
import Language.Haskell.TH.Quote (QuasiQuoter(..))

import qualified ML.Util.Lex as Lex
import Text.ParserCombinators.Parsec
import Text.ParserCombinators.Parsec.Expr

import ML.Util.Print (Print)
import Text.PrettyPrint.HughesPJ ((<+>))
import qualified ML.Util.Print as PP
import qualified Text.PrettyPrint.HughesPJ as PP
import TextShow

deriving instance Data Expr

parseExpr = buildExpressionParser table atomic <?> "expr"
  where
   op s f = Infix (Lex.reservedOp s >> pure f)
   table = [ [op "*" Mul AssocRight]
           , [op "+" Add AssocRight]
           ]
   atomic = Const <$> Lex.integer
        <|> Var <$> Lex.identifier
        <|> Lex.parens parseExpr
        <?> "atomic expr"

expr :: QuasiQuoter
expr = QuasiQuoter
         (S.liftData . Lex.makeParser parseExpr)
         undefined
         undefined
         undefined

instance Print Expr where
  pPrint = pp 0

deriving instance Show Expr

instance TextShow Expr where
  showb = fromString . PP.render . PP.pPrint


pp :: Int -> Expr -> PP.Doc
pp _ (Var s) = PP.text s
pp _ (Const n) = PP.integer n
pp pr (Add e1 e2) =
     let doc1 = pp 3 e1
         doc2 = pp 2 e2
         doc3 = doc1 <+> PP.text "+" <+> doc2 in
     if pr > 2 then PP.parens doc3 else doc3
pp pr (Mul e1 e2) =
     let doc1 = pp 5 e1
         doc2 = pp 4 e2
         doc3 = doc1 <+> PP.text "*" <+> doc2 in
     if pr > 4 then PP.parens doc3 else doc3
