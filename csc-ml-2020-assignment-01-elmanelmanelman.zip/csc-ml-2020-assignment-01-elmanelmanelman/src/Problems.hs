{-# LANGUAGE QuasiQuotes #-}

import TextShow

import ML.ArithExpr
import ML.Util.ExprPPP

import ML.PropFormula
import ML.Util.PropPPP

import ML.Prop

import Data.Char

import Control.Parallel.Strategies

-- Problem 1. Generate all formulas with at most n nodes in the abstract syntax tree

-- Generates n default props 
defaultProps :: Int -> [AtomicProp]
defaultProps n
    | n == 0              = []
    | n >= 1 && n <= maxn = map (\c -> [c]) ['a'..(chr ((ord 'a') + n - 1))]
    | otherwise           = error ("defaultProps: n must be in the range 0.." ++ (show maxn))
    where maxn = (ord 'z' - ord 'a' + 1)

-- Generates a list of all formulas with given props and exactly n nodes in the AST
formulasWithProps :: [AtomicProp] -> Int -> [PropFormula]
formulasWithProps props 0 = []
formulasWithProps props 1 = [FFalse, FTrue] ++ (map (\p -> Atom p) props)
formulasWithProps props n =
    let notFormulas      = [Not a | a <- formulasWithProps props (n - 1)]
        binFormulas conn = [conn a b | i <- [1..n - 1], a <- formulasWithProps props i, b <- formulasWithProps props (n - i - 1)] `using` parList rseq
    in notFormulas ++ (foldr (++) [] (map binFormulas [And, Or, Imp, Iff] `using` parList rseq))

-- Generates a list of all formulas with m props and n nodes in the AST
formulas :: Int -> Int -> [PropFormula]
formulas m n = formulasWithProps (defaultProps m) n

-- Generates a list of all formulas with m props and at most n nodes in the AST
formulasAtMost :: Int -> Int -> [PropFormula]
formulasAtMost m n = foldr (++) [] [formulas m i | i <- [1..n]]

-- Example
problem1 = do
    putStrLn "Problem 1. Generate all formulas with at most n nodes in the abstract syntax tree"
    putStrLn "Formulas without props"
    mapM printT [formulasAtMost 0 i | i <- [1..3]]
    putStrLn "Formulas with one prop"
    mapM printT [formulasAtMost 1 i | i <- [1..3]]
    putStrLn "Formulas with two props"
    mapM printT [formulasAtMost 2 i | i <- [1..3]]
    putStrLn " "

-- Problem 2. Count propositional formulas with specific properties (tautologies and satisfiable formulas)

-- Counts formulas with m props and of size n
countFormulas :: Int -> Int -> Int
countFormulas m n = length (formulas m n)

-- Counts tautological formulas with m props and of size n
countTautologies :: Int -> Int -> Int
countTautologies m n = length (filter (\p -> tautology p) (formulas m n))

-- Counts satisfiable formulas with m props and of size n
countSatisfiable :: Int -> Int -> Int
countSatisfiable m n = length (filter (\p -> satisfiable p) (formulas m n))

-- Data generators

-- Generates a list of ratios of tautologies among formulas with m props and of size 1..n
tautologiesRatios :: Int -> Int -> [Float]
--tautologiesRatios m n = [(fromIntegral (countTautologies m i)) / (fromIntegral (countFormulas m i)) | i <- [1..n]]
tautologiesRatios m n = 
    let calculateRatio = (\i -> (fromIntegral (countTautologies m i)) / (fromIntegral (countFormulas m i)))
    in map calculateRatio [i | i <- [1..n]] `using` parList rdeepseq

-- Generates a list of ratios of satisfiable formulas among formulas with m props and of size 1..n
satisfiableRatios :: Int -> Int -> [Float]
-- satisfiableRatios m n = [(fromIntegral (countSatisfiable m i)) / (fromIntegral (countFormulas m i)) | i <- [1..n]]
satisfiableRatios m n = 
    let calculateRatio = (\i -> (fromIntegral (countSatisfiable m i)) / (fromIntegral (countFormulas m i)))
    in map calculateRatio [i | i <- [1..n]] `using` parList rdeepseq

problem2 = do
    putStrLn "Problem 2. Count propositional formulas with specific properties"
    putStrLn $ "Tautologies with one prop"
    printT $ tautologiesRatios 1 10
    putStrLn $ "Satisfiable formulas with one prop"
    printT $ satisfiableRatios 1 10
    putStrLn $ "Tautologies with two props"
    printT $ tautologiesRatios 2 10
    putStrLn $ "Satisfiable formulas with two props"
    printT $ satisfiableRatios 2 10
    putStrLn $ "Tautologies with three props"
    printT $ tautologiesRatios 3 10
    putStrLn $ "Satisfiable formulas with three props"
    printT $ satisfiableRatios 3 10
    putStrLn " "

main = do
    -- problem1
    problem2