﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;
using System.Threading;

namespace Synchronization
{
    [HtmlExporter]
    [RPlotExporter]
    public class SynchronizationBenchmark
    {
        [Params(10, 100, 1000, 10000)] public int MessageCount = 1000;

        [Params(1, 2, 4, 16)] public int ReaderCount = 2;

        [Params(1, 2, 4, 16)] public int WriterCount = 2;

        public Thread[] Readers { get; set; }
        public Thread[] Writers { get; set; }

        public string Buffer { get; set; }
        public bool BufferEmpty { get; set; }
        public bool ReadersFinish { get; set; }
        
        public List<string>[] ReadersMessages;

        public void Init(ParameterizedThreadStart readerStart, ParameterizedThreadStart writerStart)
        {
            Readers = new Thread[ReaderCount];
            Writers = new Thread[WriterCount];
            for (var i = 0; i < ReaderCount; i++) Readers[i] = new Thread(readerStart);
            for (var i = 0; i < WriterCount; i++) Writers[i] = new Thread(writerStart);

            Buffer = "";
            BufferEmpty = true;
            ReadersFinish = false;

            ReadersMessages = new List<string>[ReaderCount];
            for (var i = 0; i < ReaderCount; i++) ReadersMessages[i] = new List<string>();
        }

        public void Start()
        {
            for (var i = 0; i < WriterCount; i++) Writers[i].Start(i);
            for (var i = 0; i < ReaderCount; i++) Readers[i].Start(i);
        }

        public bool CheckMessages()
        {
            var allMessages = new HashSet<string>();
            for (var i = 0; i < ReaderCount; i++)
                foreach (var message in ReadersMessages[i])
                    allMessages.Add(message);

            var expectedMessageCount = MessageCount * WriterCount;
            if (allMessages.Count != expectedMessageCount)
            {
                Console.WriteLine($"message count differ: expected {expectedMessageCount}, got {allMessages.Count}");
                return false;
            }

            for (var writerIndex = 0; writerIndex < WriterCount; writerIndex++)
            for (var messageIndex = 0; messageIndex < MessageCount; messageIndex++)
            {
                var message = $"{writerIndex}_{messageIndex}";
                if (allMessages.Contains(message)) continue;
                Console.WriteLine($"message \"{message}\" not found in the aggregate list");
                return false;
            }

            return true;
        }

        public void NoSync()
        {
            Init(o =>
            {
                var readerIndex = (int)o;
                while (!ReadersFinish)
                {
                    if (BufferEmpty) continue;
                    ReadersMessages[readerIndex].Add(Buffer);
                    BufferEmpty = true;
                }
            }, o =>
            {
                var writerIndex = (int)o;
                var messagesToWrite = new string[MessageCount];
                for (var i = 0; i < MessageCount; i++) messagesToWrite[i] = $"{writerIndex}_{i}";
                var messagesIndex = 0;
                while (messagesIndex < MessageCount)
                {
                    if (!BufferEmpty) continue;
                    Buffer = messagesToWrite[messagesIndex++];
                    BufferEmpty = false;
                }
            });
            Start();
            for (var i = 0; i < WriterCount; i++) Writers[i].Join();
            ReadersFinish = true;
            for (var i = 0; i < ReaderCount; i++) Readers[i].Join();
            CheckMessages();
        }

        [Benchmark(Description = "Lock")]
        public void SyncLock()
        {
            Init(o =>
            {
                var readerIndex = (int)o;

                while (!ReadersFinish)
                {
                    if (BufferEmpty) continue;
                    lock ("read")
                    {
                        if (BufferEmpty) continue;
                        ReadersMessages[readerIndex].Add(Buffer);
                        BufferEmpty = true;
                    }
                }
            }, o =>
            {
                var writerIndex = (int)o;

                var messagesToWrite = new string[MessageCount];
                for (var messageIndex = 0; messageIndex < MessageCount; messageIndex++)
                    messagesToWrite[messageIndex] = $"{writerIndex}_{messageIndex}";

                var messagesIndex = 0;
                while (messagesIndex < MessageCount)
                {
                    if (!BufferEmpty) continue;
                    lock ("write")
                    {
                        if (!BufferEmpty) continue;
                        Buffer = messagesToWrite[messagesIndex++];
                        BufferEmpty = false;
                    }
                }
            });
            Start();
            for (var i = 0; i < WriterCount; i++) Writers[i].Join();
            ReadersFinish = true;
            for (var i = 0; i < ReaderCount; i++) Readers[i].Join();
            CheckMessages();
        }

        [Benchmark(Description = "AutoResetEvent")]
        public void SyncAutoResetEvent()
        {
            var bufferEmptyEvent = new AutoResetEvent(true);
            var bufferFullEvent = new AutoResetEvent(false);

            Init(o =>
            {
                var readerIndex = (int)o;

                while (!ReadersFinish)
                {
                    bufferFullEvent.WaitOne();
                    if (ReadersFinish)
                    {
                        bufferFullEvent.Set();
                        break;
                    }
                    ReadersMessages[readerIndex].Add(Buffer);
                    bufferEmptyEvent.Set();
                }
            }, o =>
            {
                var writerIndex = (int)o;

                var messagesToWrite = new string[MessageCount];
                for (var messageIndex = 0; messageIndex < MessageCount; messageIndex++)
                    messagesToWrite[messageIndex] = $"{writerIndex}_{messageIndex}";

                var messagesIndex = 0;
                while (messagesIndex < MessageCount)
                {
                    bufferEmptyEvent.WaitOne();
                    Buffer = messagesToWrite[messagesIndex++];
                    bufferFullEvent.Set();
                }
            });
            Start();
            for (var i = 0; i < WriterCount; i++) Writers[i].Join();
            ReadersFinish = true;
            bufferFullEvent.Set();
            for (var i = 0; i < ReaderCount; i++) Readers[i].Join();
            CheckMessages();
        }
        /*
        [Benchmark(Description = "ManualResetEvent")]
        public void SyncManualResetEvent()
        {
            var bufferEmptyEvent = new ManualResetEvent(true);
            var bufferFullEvent = new ManualResetEvent(false);

            // round-robin
            var nextReader = 0;
            var nextWriter = 0;

            Init(o =>
            {
                var readerIndex = (int)o;

                while (!ReadersFinish)
                {
                    Console.WriteLine($"reader {readerIndex} waiting");
                    bufferFullEvent.WaitOne();
                    if (readerIndex != nextReader) continue;
                    Console.WriteLine($"reader {readerIndex} is next reader");
                    
                    if (ReadersFinish) break;
                    Console.WriteLine($"reader {readerIndex} is not finished");
                    ReadersMessages[readerIndex].Add(Buffer);
                    Console.WriteLine($"reader {readerIndex} add message {Buffer} to the list");

                    nextReader = (nextReader + 1) % ReaderCount;
                    Console.WriteLine($"reader {readerIndex} set nextReader to {nextReader}");

                    bufferFullEvent.Reset();
                    Console.WriteLine($"reader {readerIndex} reset bufferFullEvent");

                    bufferEmptyEvent.Set();
                }
            }, o =>
            {
                var writerIndex = (int)o;

                var messagesToWrite = new string[MessageCount];
                for (var messageIndex = 0; messageIndex < MessageCount; messageIndex++)
                    messagesToWrite[messageIndex] = $"{writerIndex}_{messageIndex}";

                var messagesIndex = 0;
                while (messagesIndex < MessageCount)
                {
                    Console.WriteLine($"writer {writerIndex} waiting");
                    bufferEmptyEvent.WaitOne();
                    if (writerIndex != nextWriter) continue;
                    Console.WriteLine($"writer {writerIndex} is next writer");

                    

                    Buffer = messagesToWrite[messagesIndex++];
                    Console.WriteLine($"writer {writerIndex} write {Buffer} to the buffer");

                    nextWriter = (nextWriter + 1) % WriterCount;
                    Console.WriteLine($"writer {writerIndex} set nextWriter to {nextWriter}");

                    bufferEmptyEvent.Reset();
                    Console.WriteLine($"writer {writerIndex} reset bufferEmptyEvent");

                    bufferFullEvent.Set();
                }
            });
            Start();
            for (var i = 0; i < WriterCount; i++) Writers[i].Join();
            ReadersFinish = true;
            bufferFullEvent.Set();
            for (var i = 0; i < ReaderCount; i++) Readers[i].Join();
            CheckMessages();
        }
        */
        [Benchmark(Description = "Semaphore")]
        public void SyncSemaphore()
        {
            var semaphoreBufferEmpty = new Semaphore(1, 1);

            Init(o =>
            {
                var readerIndex = (int)o;

                while (!ReadersFinish)
                {
                    if (BufferEmpty) continue;
                    semaphoreBufferEmpty.WaitOne();
                    if (!BufferEmpty)
                    {
                        ReadersMessages[readerIndex].Add(Buffer);
                        BufferEmpty = true;
                    }
                    semaphoreBufferEmpty.Release();
                }
            }, o =>
            {
                var writerIndex = (int)o;

                var messagesToWrite = new string[MessageCount];
                for (var messageIndex = 0; messageIndex < MessageCount; messageIndex++)
                    messagesToWrite[messageIndex] = $"{writerIndex}_{messageIndex}";

                var messagesIndex = 0;
                while (messagesIndex < MessageCount)
                {
                    if (!BufferEmpty) continue;
                    semaphoreBufferEmpty.WaitOne();
                    if (BufferEmpty)
                    {
                        Buffer = messagesToWrite[messagesIndex++];
                        BufferEmpty = false;
                    }
                    semaphoreBufferEmpty.Release();
                }
            });
            Start();
            for (var i = 0; i < WriterCount; i++) Writers[i].Join();
            ReadersFinish = true;
            for (var i = 0; i < ReaderCount; i++) Readers[i].Join();
            CheckMessages();
        }

        [Benchmark(Description = "SemaphoreSlim")]
        public void SyncSemaphoreSlim()
        {
            var semaphoreBufferEmpty = new SemaphoreSlim(1);

            Init(o =>
            {
                var readerIndex = (int)o;

                while (!ReadersFinish)
                {
                    if (BufferEmpty) continue;
                    semaphoreBufferEmpty.Wait();
                    if (!BufferEmpty)
                    {
                        ReadersMessages[readerIndex].Add(Buffer);
                        BufferEmpty = true;
                    }
                    semaphoreBufferEmpty.Release();
                }
            }, o =>
            {
                var writerIndex = (int)o;

                var messagesToWrite = new string[MessageCount];
                for (var messageIndex = 0; messageIndex < MessageCount; messageIndex++)
                    messagesToWrite[messageIndex] = $"{writerIndex}_{messageIndex}";

                var messagesIndex = 0;
                while (messagesIndex < MessageCount)
                {
                    if (!BufferEmpty) continue;
                    semaphoreBufferEmpty.Wait();
                    if (BufferEmpty)
                    {
                        Buffer = messagesToWrite[messagesIndex++];
                        BufferEmpty = false;
                    }
                    semaphoreBufferEmpty.Release();
                }
            });
            Start();
            for (var i = 0; i < WriterCount; i++) Writers[i].Join();
            ReadersFinish = true;
            for (var i = 0; i < ReaderCount; i++) Readers[i].Join();
            CheckMessages();
        }

        [Benchmark(Description = "Interlocked")]
        public void SyncInterlocked()
        {
            var bufferEmpty = 1;
            var bufferFull = 0;

            Init(o =>
            {
                var readerIndex = (int) o;

                while (!ReadersFinish)
                {
                    if (Interlocked.CompareExchange(ref bufferFull, 0, 1) != 1) continue;
                    ReadersMessages[readerIndex].Add(Buffer);
                    bufferEmpty = 1;
                }
            }, o =>
            {
                var writerIndex = (int) o;

                var messagesToWrite = new string[MessageCount];
                for (var messageIndex = 0; messageIndex < MessageCount; messageIndex++)
                    messagesToWrite[messageIndex] = $"{writerIndex}:{messageIndex}";

                var messagesIndex = 0;
                while (messagesIndex < MessageCount)
                {
                    if (Interlocked.CompareExchange(ref bufferEmpty, 0, 1) != 1) continue;
                    Buffer = messagesToWrite[messagesIndex++];
                    bufferFull = 1;
                }
            });
            Start();
            for (var i = 0; i < WriterCount; i++) Writers[i].Join();
            ReadersFinish = true;
            for (var i = 0; i < ReaderCount; i++) Readers[i].Join();
            CheckMessages();
        }
    }

    internal class Program
    {
        private static void Main()
        {
            var s = new SynchronizationBenchmark();

            BenchmarkRunner.Run<SynchronizationBenchmark>();
        }
    }
}